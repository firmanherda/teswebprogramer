<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <h4>Daftar Produk</h4>

                <div class="row align-items-center">
                    <div class="col-md-6 d-flex align-items-center">
                        <input type="text" class="me-2" placeholder="Search.." name="search" id="search" value="<?php echo e(Session::get('search_query')); ?>">
                        <select name="category" class="" id="category">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e(Session::get('selected_category') == $data->id ? 'selected' : ''); ?>><?php echo e($data->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 text-end">
                        <a href="<?php echo e(route('admin.product.exportFiltered', ['category' => $selectedCategory, 'search' => $searchQuery])); ?>" class="btn btn-primary me-2" style="background-color: green">Export Excel</a>
                        <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-primary">Tambah Produk</a>
                    </div>
                </div>

                <div class="card my-4">
                    <div class="card-body px-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center">
                                <tr>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Image</th>
                                    <th>Nama Produk</th>
                                    <th>Kategori Produk</th>
                                    <th>Harga Beli (Rp)</th>
                                    <th>Harga Jual (Rp)</th>
                                    <th>Stok Produk</th>
                                    <th>Aksi</th>
                                </tr>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                        <td>
                                            <div class="text-center">
                                                <a href="<?php echo e(asset($data->image)); ?>" target="_blank">
                                                    <div>
                                                        <img src="<?php echo e(asset($data->image)); ?>" class="avatar avatar-sm border-radius-lg" alt="user1">
                                                    </div>
                                                </a>
                                            </div>
                                        </td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->category_name); ?></td>
                                        <td><?php echo e(number_format($data->purchase_price, 0, ',')); ?></td>
                                        <td><?php echo e(number_format($data->selling_price, 0, ',')); ?></td>
                                        <td><?php echo e($data->stock); ?></td>
                                        <td>
                                            <?php echo $data->edit; ?>

                                            &nbsp;
                                            <?php echo $data->delete; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>Show <?php echo e($products->perPage()); ?> from <?php echo e($products->total()); ?></div>
                    <div><?php echo e($products->onEachSide(0)->links()); ?></div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelector('#search').addEventListener('input', function() {
            filterProducts();
        });

        document.querySelector('#category').addEventListener('change', function() {
            filterProducts();
        });

        function filterProducts() {
            var searchValue = document.querySelector('#search').value;
            var categoryValue = document.querySelector('#category').value;

            // Redirect ke halaman index dengan parameter query string yang sesuai
            var baseUrl = "<?php echo e(route('admin.product.index')); ?>";
            var url = baseUrl + "?search=" + searchValue + "&category=" + categoryValue;
            window.location.href = url;
        }


        // Delete Validation
        const deleteButtons = document.querySelectorAll('.modal-deletetab');

        deleteButtons.forEach(button => {
            button.addEventListener('click', function(event) {
                event.preventDefault(); // Menghentikan tindakan bawaan dari link

                const id = this.getAttribute('data-id');

                swal({
                    title: "Yakin?",
                    text: "kamu akan menghapus data ini ?",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((willDelete) => {
                    if (willDelete) {
                        window.location =
                                "/admin/product/destroy/" + id + "";
                        swal("Data berhasil dihapus", {
                            icon: "success",
                        });
                    } else {
                        swal("Data Tidak Jadi dihapus");
                    }
                });
            });
        });
        // End Delete Validation
    });

</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itbookingtogo/Development/asidikfauzi/testwebprogramerr/resources/views/product/index.blade.php ENDPATH**/ ?>