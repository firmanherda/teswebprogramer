<?php $__env->startSection('content'); ?>
	<div class="container-fluid py-4">
		<div class="row">
			<div class="col-12">

				<div class="row align-items-center">
					<div class="col-md-6 d-flex align-items-center">
						<!-- Gambar bundar -->
						<div class="rounded-circle overflow-hidden me-3" style="width: 200px; height: 200px;">
							<img src="<?php echo e(asset($user->image)); ?>" class="w-100 h-100" alt="Profile Picture">
						</div>
						<!-- Ikon edit -->
						<i class="fas fa-edit text-primary"></i>
					</div>
					<h2><?php echo e(Auth::user()->name); ?></h2>
					<div class="row">
						<div class="col-md-6">
							<div class="mb-3">
								<label for="category" class="form-label">Nama Kandidat</label>
								<input type="text" class="form-control form-control-lg" name="name" id="name" value="<?php echo e(Auth::user()->name); ?>">
								<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="form" style="font-size: 12px; color: red"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-md-6">
							<div class="mb-3">
								<label for="name" class="form-label">Posisi Kandidat</label>
								<input type="text" class="form-control form-control-lg" name="name" id="name" value="<?php echo e(Auth::user()->candidate_position); ?>">
								<?php $__errorArgs = ['candidate_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="form" style="font-size: 12px; color: red"><?php echo e($message); ?></div>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
					</div>


				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/itbookingtogo/Development/asidikfauzi/testwebprogramerr/resources/views/profile/index.blade.php ENDPATH**/ ?>